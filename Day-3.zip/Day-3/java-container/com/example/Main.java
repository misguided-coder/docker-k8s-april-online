package com.example;

public class Main {

	public static void main(String[] args) {
		InfoService  infoService  = new InfoService();
 		infoService.displayInfo();
		WeatherService  weatherService  = new WeatherService();
		weatherService.displayWeather();
	}

}