public class InfoService {

	public static void main(String[] args) {		
		System.out.println("Take me anywhere and I will go alnong with container and run everywhere!!!!");		
	}

}