package com.example;

public class WeatherService {

	public void displayWeather() {		
		System.out.println("Weather is very hot outside!!!!");		
	}

}