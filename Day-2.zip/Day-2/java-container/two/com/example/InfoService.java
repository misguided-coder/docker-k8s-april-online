package com.example;

public class InfoService {

	public void displayInfo() {		
		System.out.println("Take me anywhere and I will go alnong with container and run everywhere!!!!");		
	}

}